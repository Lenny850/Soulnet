SOULNET PWA – STARTANLEITUNG

Enthalten:
- index.html: SoulNet-Oberfläche
- manifest.webmanifest + icon.svg: Installationsdaten
- sw.js: Offline-Grundgerüst

WICHTIG – WAS DIESE VERSION KANN:
- Läuft als responsive Web-App auf PC und Handy.
- Uhrzeit live; Wetterdaten für Leipzig via Open-Meteo (Internet nötig).
- Bilder, Links und Sammlungen werden lokal im Browser dieses Geräts gespeichert (IndexedDB).
- Basis-Oberfläche für Soul AI; es wird noch kein Bild an eine KI geschickt.
- Mitgliederbereich ist derzeit nur eine Vorschau.

WAS NOCH NICHT ECHT IST:
- Kein Benutzerkonto/Passwort-Login.
- Keine Synchronisation zwischen Geräten.
- Keine getrennten privaten Cloud-Galerien für drei Nutzer.
- Keine echte Online-Anzeige anderer Nutzer.
- Keine KI-Anbindung.

INSTALLATION:
1. ZIP entpacken.
2. Dateien auf einen HTTPS-Webhost hochladen (z.B. einen statischen Webhost). PWA-Installation benötigt HTTPS.
3. Die veröffentlichte HTTPS-Adresse auf PC und iPhone öffnen.
4. PC: In Chrome oder Edge das Installieren-Symbol in der Adressleiste wählen oder Menü > Installieren.
5. iPhone: In Safari öffnen > Teilen > Zum Home-Bildschirm > Hinzufügen.
6. Beide Geräte greifen erst dann auf denselben Datenbestand zu, wenn ein Cloud-Backend ergänzt wird. Diese Demo synchronisiert NICHT.

ENTWICKLUNGSSTAND:
Dies ist ein installierbarer Frontend-Prototyp, noch kein sicherer Mehrbenutzer-Cloud-Dienst.
Für die nächste Ausbaustufe ist ein Backend (z.B. Supabase) nötig. Passwörter oder API-Schlüssel niemals in index.html eintragen oder im Chat senden.
